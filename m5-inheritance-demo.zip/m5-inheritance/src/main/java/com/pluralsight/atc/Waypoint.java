package com.pluralsight.atc;

public class Waypoint  {

}
